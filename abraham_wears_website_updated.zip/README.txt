ABRAHAM.WEARS — UPDATED FREE WEBSITE STARTER

Files:
- index.html: responsive catalogue website with your contact links added.
- README.txt: these publishing instructions.

CONTACT LINKS ADDED:
- WhatsApp: https://wa.me/923343006725
- Instagram: https://www.instagram.com/abraham.wears?exln=cHBqeGQyY3IwZzNh

FREE HOSTING OPTION — GITHUB PAGES:
1. Open https://github.com/ and create/sign in to your account.
2. Create a new repository named abraham-wears-website. For the simplest setup, choose Public.
3. Upload index.html to the repository root (top level).
4. Open the repository's Settings tab.
5. In the left sidebar, select Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose branch main and folder /(root), then click Save.
8. Wait for the deployment to finish. The Pages section will show your live website address, usually:
   https://YOUR-GITHUB-USERNAME.github.io/abraham-wears-website/

BEFORE SHARING:
- Open the live website and test both contact buttons.
- Replace emoji product placeholders with your own product photos.
- Check that all product details and business claims are accurate.

COST:
GitHub Pages can host a public static website for free. A custom .com domain usually costs extra.
This is a product catalogue, not a checkout/payment system. No customer data is collected by this starter page.
